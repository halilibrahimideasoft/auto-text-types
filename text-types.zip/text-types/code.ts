figma.showUI(__html__);

const getLocalVariables = figma.getLocalTextStyles();

const fontWeightTypes: { [key: string]: number } = {
  "Thin":100,
  "ExtraLight": 200,
  "Light": 300,
  "Regular": 400,
  "Medium": 500,
  "SemiBold": 600,
  "Bold": 700,
  "ExtraBold": 800,
  "Black": 900
}

const mixinNameTypes: { [key: string]: string } = {
  "Body Text/Text 1": "text-type-1",
  "Body Text/Text 2": "text-type-2",
  "Body Text/Text 3": "text-type-3",
  "Body Text/Text 4": "text-type-4",
  "Body Text/Text 5": "text-type-5",
  "Body Text/Text 6": "text-type-6",
  "Heading Text/Headign 1": "heading-type-1",
  "Heading Text/Headign 2": "heading-type-2",
  "Heading Text/Headign 3": "heading-teype-4",
  "Heading Text/Headign 5": "heading-type-5",
  "Heading Text/Heading 6": "heading-type-6",
}

figma.ui.onmessage = (message) => {
  let templateMixin = '';

  getLocalVariables.map((item) => {    
    if(Object.keys(mixinNameTypes).includes(item.name)){
      console.log(item.name);
      
      templateMixin += `
        @mixin ${mixinNameTypes[item.name]} {
          @include line-rule(${item.fontSize});
          font-weight: ${fontWeightTypes[item.fontName.style] ?? 'Tanımlanmayan Weight Değeri!'};
        }
      `;
    }
  });

  figma.ui.postMessage(templateMixin);
}

console.log(figma.getLocalPaintStyles());
